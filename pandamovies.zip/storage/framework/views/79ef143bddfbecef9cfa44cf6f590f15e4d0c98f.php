
 
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row" style="margin:15px 0;"><div class="col-lg-6">
            <h3>Dashboard</h3>
        </div>
            
            <div class="col-lg-6"  style="display:flex;justify-content:flex-end;">
                <a class="btn btncolor" href="<?php echo e(route('contentsadmin.create')); ?>"> Add New Item</a>
            </div>
        </div>
        
        <hr style="border:1px solid "> 
            

    
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" style="background-color:rgb(37, 29, 56)">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    
   <div class="row">
    <div class="col-sm-12 col-md-12 col-lg-6 mb-3">
<div style="border-radius:10px;width:290px;height:auto;background:#151f30;padding:10px;font-size:24px;display:flex;justify-content:center;">Total movies added: <?php echo e($contents->count()); ?> </div>
    </div>
    <div class="col-sm-12 col-md-12 col-lg-6">
        
    </div>
    </div>
<div class="row">
    <div class="col-sm-12 col-md-6 col-lg-6">
    <div class="card card1">
  <div class="card-header" style="padding-right:20px;display:flex;justify-content:space-between;align-items:center;">
    <b>Popular movies</b><a href="" class="btn btncard" >See all</a>
  </div>
  <div class="card-body">
  <table style="width:100%">
  <tr>
  <th>Id</th>
    <th style="width:30%;">Title</th>
    <th>Rating</th>
    <th>Views</th>
    <th>Action</th>
  </tr>
  <?php $__currentLoopData = $contents1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr class="tr">
    <td><?php echo e($content1->id); ?></td>
    <td style="width:30%;"><?php echo e($content1->title); ?></td>
    <td>$<?php echo e($content1->rating); ?></td>
    <td><?php echo e($content1->views); ?></td>
    <td style="display:flex;justify-content:start;">
                <form action="<?php echo e(route('contentsadmin.destroy',$content1->id)); ?>" method="POST">
   
                <a class="btn btncolor" href="<?php echo e(route('contentsadmin.edit',$content1->id)); ?>"><i class="fas fa-pen-fancy"></i>
</a>
                    <a class="btn btncolor" href="<?php echo e(route('show',$content1->id)); ?>"><i class="fas fa-eye"></i>
</a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btncolor"><i class="fas fa-trash-alt"></i></button>
                </form>
            </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
    
    
  </div>
</div>
    </div>
    <div class="col-sm-12 col-md-6 col-lg-6">
    <div class="card card2">
  <div class="card-header"style="padding-right:20px;display:flex;justify-content:space-between;align-items:center;">
  <b>Recently added movies</b> <a href="" class="btn btncard">See all</a>
  </div>
  <div class="card-body">
  <table style="width:100%">
  <tr>
  <th>Id</th>
    <th style="width:30%;">Title</th>
    <th >Rating</th>
    <th>Views</th>
    <th >Action</th>
  </tr>
  <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($content->id); ?></td>
    <td style="width:30%;"><?php echo e($content->title); ?></td>
    <td>$<?php echo e($content->rating); ?></td>
    <td><?php echo e($content->views); ?></td>
    <td style="display:flex;justify-content:start;">
                <form action="<?php echo e(route('contentsadmin.destroy',$content->id)); ?>" method="POST">
   
                <a class="btn btncolor" href="<?php echo e(route('contentsadmin.edit',$content->id)); ?>"><i class="fas fa-pen-fancy"></i>
</a>
                    <a class="btn btncolor" href="<?php echo e(route('show',$content->id)); ?>"><i class="fas fa-eye"></i>
</a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btncolor"><i class="fas fa-trash-alt"></i></button>
                </form>
            </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
    
  </div>
</div>  
    
  
    
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('contents.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pandamovie\resources\views/contents/index.blade.php ENDPATH**/ ?>