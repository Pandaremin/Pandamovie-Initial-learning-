
  
<?php $__env->startSection('content'); ?>
<div class="container" >
  
<h1 class="showcase-heading"><b>Recently added</b></h1>
    <div class="row" id="row">
        
    <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-4 col-sm-4 col-md-3 col-lg-2 movieClick">
         <div class="movie">
         
         <a href="<?php echo e(route('show',$contents->id)); ?>"><img src="<?php echo e($contents ->poster); ?>" alt=""></a>
         </div>
         <div class="movieinfoellispe">
         <div class="movie-info">
          <p><?php echo e($contents->title); ?></p>
          
         </div>
         </div>
         
       </div>
            
            
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>  

  </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mainpage.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pandamovies\resources\views/mainpage/search.blade.php ENDPATH**/ ?>