
  
<?php $__env->startSection('content'); ?>


  <div style="margin-top: 100px;">
    <h1 class="showcase-heading"><b>Recently added</b></h1>
    <div class="row" id="row">
     <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-4 col-sm-4 col-md-3 col-lg-2 movieClick">
         <div class="movie">
         
         <a href="<?php echo e(route('show',$content->id)); ?>"><img src="<?php echo e($content->poster); ?>" alt="">
      </a>
         </div>
         <div class="movieinfoellispe">
         <div class="movie-info">
          <p><?php echo e($content->title); ?></p>
          
      </div>
         </div>
         
       </div>
            
            
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>  
<?php echo $contents->links(); ?>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontcontents.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pandamovie\resources\views/frontcontents/index.blade.php ENDPATH**/ ?>