<!DOCTYPE html>
<html>
<head>
    <title>Pandamovie</title>
    <script src="https://kit.fontawesome.com/784194f36f.js" crossorigin="anonymous"></script>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(url('css/adminstyle.css')); ?>">
</head>
<body>
  
<div>
    <?php echo $__env->yieldContent('content'); ?>
</div>
<footer class="text-center mt-5 py-4 text-muted">
    <img src="https://i.pinimg.com/originals/b2/ce/98/b2ce98392df5c686796e9233d77175fc.gif" width="40px" height="30px" alt=""> &copy; 2021 Copyright: Pandamovie</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\pandamovie\resources\views/contents/layout.blade.php ENDPATH**/ ?>