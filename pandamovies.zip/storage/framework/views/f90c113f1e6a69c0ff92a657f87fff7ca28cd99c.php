
<?php $__env->startSection('content'); ?>


<div class="row">
              <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                <div class="iframe-container">
                <IFRAME SRC="<?php echo e($content->download1); ?>" FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING=NO WIDTH=100% HEIGHT=315 allowfullscreen></IFRAME>
              </div>
              </div>
              
          
             </div>
    
    
        <div class="row mt-5">
        <div class="col-lg-4 col-sm-0 col-md-0" >
        
        <img style="border-radius:5px;" src="<?php echo e($content->poster); ?>" width="100%" alt="">

        </div>
        <div class="col-lg-8 col-sm-12 col-md-12">
        
            <div class="form-group mt-3">
                <h3><b><?php echo e($content->title); ?></b></h3>
            </div>
            <div class="form-group">
                
                <?php echo e($content->info); ?>

            </div>
            <div class="form-group">
            <i class="far fa-star"></i>
                <?php echo e($content->rating); ?>/10   
                
            </div>
            <div class="form-group">
            
                <i class="far fa-clock"></i> <?php echo e($content->duration); ?>    
                
            </div>
            <div class="form-group">
            
                <i class="far fa-calendar-alt"></i> <?php echo e($content->releasedate); ?>

            </div>
            <div class="form-group">
            
             <div class="form-group">
            
             <a style="color:blue;" class="btn btncolor" href="<?php echo e($content->trailer); ?>"> <i class="fas fa-play-circle"></i> Trailer</a>
             <a style="margin-left:10px; color:blue;" class="btn btncolor" href="<?php echo e($content->trailer); ?>"> Download</a>
            </div>
        </div>
                
            </div>   
        </div>
    </div>
    

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontcontents.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pandamovie\resources\views/frontcontents/show.blade.php ENDPATH**/ ?>