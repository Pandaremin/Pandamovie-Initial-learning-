<!DOCTYPE html>
<html>
<head>
    <title>PandaMovie</title>
    <script src="https://kit.fontawesome.com/784194f36f.js" crossorigin="anonymous"></script>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>"/>
</head>
<body >
<header>
        <nav class="navbar navbar-expand-lg navbarstyle ">
          <div class="container-fluid">
            <a class="navbar-brand navv"  href="index.html"><b>PandaMovie</b></a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span style="color: white; border: 0px;">
                <i class="fas fa-bars"></i>
              </span>        </button>
              
            <div class="collapse navbar-collapse justify-content-between" " id="navbarSupportedContent"  ">
              <ul class="navbar-nav ms-auto mb-2 mb-lg-0"  >
                <li class="nav-item" id="nav-item">
                  <a class="nav-link active" aria-current="page" href="index.html">Home</a>
                </li>
                <li class="nav-item" id="nav-item">
                  <a class="nav-link" href="popular.html">Most Popular</a>
                </li>
                <li class="nav-item" id="nav-item">
                    <a class="nav-link" href="toprated.html">Top Rated</a>
                  </li
                  <li >
                
                  </li>
                  <li class="nav-item" id="nav-item"><a class="nav-link" href="recent.html">Recent Release</a></li>
                <li class="nav-item dropdown" id="nav-item">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Genre
                  </a>
                  <ul class="dropdown-menu drop " style="background-color: rgb(35, 35, 35); " aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item genre" id="genre" href="#">Action</a></li>
                    <li><a class="dropdown-item genre" id="genre" href="#">Another action</a></li>
                    <li><a class="dropdown-item genre" id="genre" href="#">Something else</a></li>
                  </ul>
                </li>
                
                <li>
                  <form id="form">
                    <input type="text" placeholder="Search here" id="search">
                  </form>
                </li>
                
              </ul>
            </div>
          </div>
        </nav>
        
        </header>
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<footer class="text-center mt-5 py-4 text-muted">
    <img src="https://i.pinimg.com/originals/b2/ce/98/b2ce98392df5c686796e9233d77175fc.gif" width="40px" height="30px" alt=""> &copy; 2021 Copyright: Panda Team</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\pandamovie\resources\views/mainpage/layout.blade.php ENDPATH**/ ?>